package ex3;

public class Meat extends Food {
    public Meat(String type, int quantity) {
        super(type, quantity);
    }
}
