package ex3;

public abstract class Mammal extends Animal {
    private String livingRegion;
    protected Mammal(String animalType, String animalName, double animalWeight, String livingRegion) {
        super(animalType, animalName, animalWeight);
        this.setLivingRegion(livingRegion);
    }

    protected String getLivingRegion(){
        return this.livingRegion;
    }

    private void setLivingRegion(String livingRegion){
        this.livingRegion = livingRegion;
    }
}
