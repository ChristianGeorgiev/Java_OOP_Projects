package ex3;

public class Vegetable extends Food {
    public Vegetable(String type, int quantity) {
        super(type, quantity);
    }

}
