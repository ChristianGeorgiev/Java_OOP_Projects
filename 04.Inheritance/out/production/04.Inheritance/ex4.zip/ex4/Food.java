package ex4;

public class Food {
}
