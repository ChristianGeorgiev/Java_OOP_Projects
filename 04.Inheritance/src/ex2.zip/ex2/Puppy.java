package ex2;

public class Puppy extends Dog {
    public void weep(){
        System.out.println("weeping...");
    }
}
