package NeedForSpeed;

public class ShowCar extends Car {
    private static final int DEFAULT_STARS = 0;
    private int stars;

    public ShowCar(String brand, String model, int yearOfProduction, int horsepower, int acceleration, int suspension, int durability) {
        super(brand, model,"Show", yearOfProduction, horsepower, acceleration, suspension, durability);
        this.stars = DEFAULT_STARS;
    }

    private int getStars() {
        return stars;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder(super.toString());
        sb.append(String.format("%d *", this.getStars()));
        return sb.toString();
    }

    @Override
    public void addAddOn(String addOn) {

    }

    @Override
    public void addStars(int stars) {
        this.stars += stars;
    }
}
