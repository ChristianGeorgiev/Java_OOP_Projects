package NeedForSpeed;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public abstract class Race {
    private int length;
    private String route;
    private int prizePool;
    private Map<Integer, Car> participants;
    private boolean isClosed;

    protected Race(int length, String route, int prizePool) {
        this.setLength(length);
        this.setRoute(route);
        this.setPrizePool(prizePool);
        this.participants = new LinkedHashMap<>();
        this.isClosed = false;
    }

    protected void addParticipant(int id, Car car){
        if (!car.isParked()) {
            car.setRacing(true);
            this.participants.put(id, car);
        }
    }

    protected Map<Integer, Car> getParticipants(){
        return Collections.unmodifiableMap(this.participants);
    }

    protected int getLength() {
        return this.length;
    }

    private void setLength(int length) {
        this.length = length;
    }

    protected String getRoute() {
        return this.route;
    }

    private void setRoute(String route) {
        this.route = route;
    }

    protected int getPrizePool(){
        return this.prizePool;
    }

    private void setPrizePool(int prizePool) {
        this.prizePool = prizePool;
    }

    protected boolean isClosed() {
        return this.isClosed;
    }

    protected void setClosed(boolean closed) {
        isClosed = closed;
    }

    @Override
    public String toString(){
        this.setClosed(true);
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("%s - %s%n", this.getRoute(), this.getLength()));

        List<Car> sortedCars = this.getParticipants().values().stream().sorted((a,b) ->
                Long.compare(b.getOverallPerformance(), a.getOverallPerformance()))
                .collect(Collectors.toList());

        for (int i = 0; i < sortedCars.size(); i++) {
            int moneyWon = 0;
            switch (i){
                case 0:
                    moneyWon = (this.getPrizePool() * 50) / 100;
                    sb.append(String.format("%d. %s %s %dPP - $%d", i+1, sortedCars.get(i).getBrand(),
                            sortedCars.get(i).getModel(), sortedCars.get(i).getOverallPerformance(), moneyWon));
                    break;
                case 1:
                    moneyWon = (this.getPrizePool() * 30) / 100;
                    sb.append(String.format("%n%d. %s %s %dPP - $%d", i+1, sortedCars.get(i).getBrand(),
                            sortedCars.get(i).getModel(), sortedCars.get(i).getOverallPerformance(), moneyWon));
                    break;
                case 2:
                    moneyWon = (this.getPrizePool() * 20) / 100;
                    sb.append(String.format("%n%d. %s %s %dPP - $%d", i+1, sortedCars.get(i).getBrand(),
                            sortedCars.get(i).getModel(), sortedCars.get(i).getOverallPerformance(), moneyWon));
                    break;
                default:
                    break;
            }
        }
        return sb.toString();
    }
}
