public class Person {
    private String firstName;
    private String lastName;
    private Integer age;
    private double salary;

    public Person (String firstName, String lastName, Integer age, double salary){
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;
        this.salary = salary;
    }

    public String getFirstName() {
        return this.firstName;
    }

    public String getLastName(){
        return this.lastName;
    }

    public int getAge() {
        return this.age;
    }

    public double getSalary(){
        return this.salary;
    }

    public void increaseSalary (double bonus){
        if (this.age > 30){
            this.salary += this.salary * bonus / 100;
        }else {
            this.salary += this.salary * bonus / 200;
        }
    }

    @Override
    public String toString(){
        //return String.format("%s %s get %f leva", this.getFirstName(), this.getLastName(), this.getSalary());

        return this.getFirstName() + " " + this.getLastName() + " get " + this.salary + " leva";
    }
}
