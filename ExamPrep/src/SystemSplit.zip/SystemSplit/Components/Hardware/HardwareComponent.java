package SystemSplit.Components.Hardware;

import SystemSplit.Components.Component;
import SystemSplit.Components.Software.SoftwareComponent;

import java.util.ArrayList;
import java.util.List;

public class HardwareComponent extends Component {
    private int maxCapacity;
    private int maxMemory;
    private List<SoftwareComponent> softwareComponents;

    protected HardwareComponent(String name, String type, int maxCapacity, int maxMemory) {
        super(name, type);
        this.maxCapacity = maxCapacity;
        this.maxMemory = maxMemory;
        this.softwareComponents = new ArrayList<>();
    }

    @Override
    public int getCapacity() {
        return this.maxCapacity;
    }

    @Override
    public int getMemory() {
        return this.maxMemory;
    }

    public void registerSoftwareComponent(SoftwareComponent softwareComponent){

    }
}
